

import 'package:flutter/material.dart';
void main()
{
  runApp(MyApp());

}
class MyApp extends StatelessWidget{
  const MyApp({Key?key}):super(key:key);

  @override
  Widget build(BuildContext context) {
   return MaterialApp(
    title: 'My chatApp',
    theme: ThemeData( primarySwatch: Colors.pink),
      debugShowCheckedModeBanner: false,
      home: const HomePage()
   );
 
  }
  
}
  class HomePage extends StatelessWidget{
  const  HomePage({Key?key}):super(key:key);

  @override
  Widget build(BuildContext context) {

     final DateTime Time= DateTime.now();
   return DefaultTabController(length: 4, child: Scaffold(
    floatingActionButton: FloatingActionButton(onPressed: (){
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('do you wnat to send a new message'),
        duration: Duration(microseconds: 1000000000),

      ));
    },child: Icon(Icons.add),),
    floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    appBar: AppBar(
      title:const Text('WhatsApp',style: TextStyle(fontSize: 33, fontWeight: FontWeight.w400)),
       
      actions: [
     const  Icon(Icons.camera_alt_sharp),
    
     SizedBox(width: 20,),
       const Icon(Icons.search),
       PopupMenuButton<int>(itemBuilder: (context)=>[
        const PopupMenuItem(child:  Text('New Group'),value:1),
         const PopupMenuItem(child:  Text('New broadcast'),value:2),
          const PopupMenuItem(child:  Text('Linked Devices'),value:3),
           const PopupMenuItem(child:  Text('Starred Messages'),value:4),
            const PopupMenuItem(child:  Text('setting'),value:5),
           ])
      ],
    
        bottom: const TabBar(
          
          tabs:
        [Tab(child:SizedBox(width: 0,
        child: Center(child:Icon(Icons.group_outlined)),),),
          Tab(child:  Text('Chats'),),
          Tab(child: const Text('Status'),),
          Tab(child: const Text('Calls'),),
          

        ]),
    ),
       body: Center(
       child: TabBarView(
        children: [
          Icon(Icons.group_sharp,size: 300,),
          ListView(children: [
          Card(
            child: ListTile(
              title: Text('Aiman'),
              subtitle: Text('where are You'),
              leading: CircleAvatar(
                backgroundColor: Colors.red,
                
              ),
              trailing:Text('$Time.toLocal()'),),
          ),
           Card(
            child: ListTile(
              title: Text('zee'),
              subtitle: Text('where are You'),
              leading: CircleAvatar(
                backgroundColor: Colors.red,
                
              ),
              trailing:Text('$Time'),),
          ), 
          Card(
            child: ListTile(
              title: Text('Sho'),
              subtitle: Text('where are You'),
              leading: CircleAvatar(
                backgroundColor: Colors.red,
                
              ),
              trailing:Text('$Time'),),
          )
          ],),
         const  Icon(Icons.notifications_rounded,color: Colors.pink, size: 350),
          const Icon(Icons.call,color: Colors.pink, size:350),
        ],
       ),
       )
       

       )

   );
  }
   
  }
 