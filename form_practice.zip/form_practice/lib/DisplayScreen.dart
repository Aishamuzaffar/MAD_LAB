import 'package:flutter/material.dart';
class DisplayScreen extends StatelessWidget{
 final String name;
  final int age;
 final String email;
 final String password;
 //final DateTime selectedDate;
  DisplayScreen({
    required this.name, required this.age, required this.email,required this.password, //required this.selectedDate
  });
  @override
   Widget build(BuildContext context)
   
   {
    return Container(decoration: const BoxDecoration(
     
    image: DecorationImage(
    image:AssetImage('images/detail.png'),fit: BoxFit.cover
    )
    ),
    child: Scaffold(
      backgroundColor: Colors.transparent,
   
    body: Center(
      child:Container(
        height: 300,
        width: 350,
        alignment: Alignment.center,
       
        child:Card(
          
          child: ListView(
            
            children: [  
      const SizedBox(height: 22,), 
      ListTile(title:   Text('Name: $name', style: TextStyle(fontSize: 18)),
      leading:const Icon(Icons.face,color: Colors.blueGrey
      ,)),
      ListTile(title:Text('Age: $age', style: TextStyle(fontSize: 18)),
      leading:const Icon(Icons.calendar_today,color: Colors.blueGrey,)),
          ListTile(title:Text('Password: $password', style: TextStyle(fontSize: 18)),
          leading:const Icon(Icons.password,color: Colors.blueGrey,)), 
          ListTile(title:  Text('Email: $email', style: TextStyle(fontSize: 18)),
      leading:const Icon(Icons.mail, color:Colors.blueGrey,)), 
      //  ListTile(title:  Text('Date Of Birth ${selectedDate.toLocal()}'.split('')[0], style: TextStyle(fontSize: 18)),
      // leading:const Icon(Icons.mail, color:Colors.pink,)),
          
      
       

          
        ],),
      ),)
    )
     ) );
   }

 }