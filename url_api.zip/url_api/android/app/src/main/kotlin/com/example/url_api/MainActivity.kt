package com.example.url_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
