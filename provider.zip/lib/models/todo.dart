import 'package:flutter/src/widgets/editable_text.dart';

class Todo{
String title;
bool isDone;
String subt;

Todo({required this.title, required this.isDone,required this.subt});

}