import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: ColorChangeExample(),
      
    );
  }
}

class ColorChangeExample extends StatefulWidget {
  @override
  _ColorChangeExampleState createState() => _ColorChangeExampleState();
}

class _ColorChangeExampleState extends State<ColorChangeExample> {
  Color _containerColor = Colors.blue; // Initial color

  void _changeColor() {
    // Toggle between blue and red colors
    setState(() {
      _containerColor = _containerColor == Colors.blue ? Colors.red : Colors.blue;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Gestures'),
      ),
      body: Center(
        child: GestureDetector(
          onTap: () {
            _changeColor();
          },
          child: Container(
            width: 200,
            height: 200,
            color: _containerColor, // Color changes based on tap
            child: Center(
              child: Text(
                'Tap Me to Change Color',
                style: TextStyle(color: Colors.white, fontSize: 18),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

