import 'package:database/db_helper.dart';
import 'package:database/note.dart';
import 'package:flutter/material.dart';


import 'package:sqflite_common_ffi/sqflite_ffi.dart';

Future main() async {
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<Map<String, dynamic>> notes = [];
  TextEditingController titlec = TextEditingController();
  TextEditingController contentc = TextEditingController();
  Future<void> _loadnotes() async {
    DbHelper dbHelper = DbHelper();
    final notelist = await dbHelper.queryAll();
    setState(() {
      notes = notelist;
    });
  }

  @override
  void initState() {
    super.initState();
    _loadnotes();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(children: <Widget>[
          Expanded(
              child: ListView.builder(
            itemCount: notes.length,
            itemBuilder: (context, index) {
              final note = notes[index];
              return ListTile(
                title: Text(note["title"]),
                subtitle: Text(note["content"]),
                trailing: IconButton(
                    onPressed: () async {
                      DbHelper dbHelper = DbHelper();
                      await dbHelper.delete(note["id"]);
                    },
                    icon: const Icon(Icons.remove)),
              );
            },
          )),
          TextField(
            controller: titlec,
            decoration: const InputDecoration(labelText: "Title"),
          ),
          TextField(
            controller: contentc,
            decoration: const InputDecoration(
              labelText: "Content",
            ),
          ),
          ElevatedButton(
            onPressed: () async {
              DbHelper dbHelper = DbHelper();
              Note note = Note(
                title: titlec.text,
                content: contentc.text,
              );
              await dbHelper.insert(note);
            },
            child: const Text("insert task"),
          )
        ]),),);}}
