import 'package:flutter/material.dart';

import 'RegistrationForm.dart';
void main()
{
  runApp(const MyApp());
}
class MyApp extends StatelessWidget{
  const MyApp({Key?key}): super(key:key);
 @override
    Widget build(BuildContext Context){
      return MaterialApp(
        title: 'MY app',
        theme: ThemeData(
          primarySwatch: Colors.blueGrey

        ),
        debugShowCheckedModeBanner: false,
     initialRoute: 'Registration',
     routes: {
      'Registration': (context)=>RegistrationForm ()
     },
      );
    }}