
import 'package:flutter/material.dart';

import 'DisplayScreen.dart';
class RegistrationForm extends StatefulWidget{
  const RegistrationForm({Key? key}) : super(key: key);


  @override
    State<RegistrationForm> createState()=>_RegistrationFormState();
}
class _RegistrationFormState extends State<RegistrationForm>{
  final _formkey=GlobalKey<FormState>();

  TextEditingController textcontroller=TextEditingController();
  TextEditingController passwordcontroller=TextEditingController();
  TextEditingController emailcontroller=TextEditingController();
  TextEditingController agecontroller=TextEditingController();
  TextEditingController dcontroller =TextEditingController();
  @override
  Widget build(BuildContext context) {
    final mediaquery=MediaQuery.of(context);
    // ignore: unused_local_variable
    final size=mediaquery.size.width;
   
    return Container(decoration: const BoxDecoration(
     
    image: DecorationImage(
    image:AssetImage('images/registration.png'),fit: BoxFit.cover
    )
    ),

      child :Scaffold(
    backgroundColor:Colors.transparent,
    
     
     body: Form(

      key: _formkey,
      child: Center(child: Column(
    mainAxisAlignment: MainAxisAlignment.center,
    crossAxisAlignment: CrossAxisAlignment.center,
      children: [
      
        Container(
          alignment: Alignment.center,
         
         child: const Text('REGISTRATION FORM', textAlign:TextAlign.center,style:
          TextStyle(color: Colors.blueGrey
         ,fontSize: 30,
        
         fontWeight: FontWeight.bold),),     
        ),
        Container(
          
            height: 500,
            width:350,
            alignment:Alignment.center,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
           
            children: [
              SizedBox(height: 4,),
              Card(
                color: Colors.white,
                elevation: 5,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                child: Center(child: Column(children: [TextFormField(
                controller:textcontroller,
                decoration: const InputDecoration(hintText: 'Full name', labelText: 'Full name',border: OutlineInputBorder()),
                validator: (value) {
                if (value!.isEmpty) {
                  return 'Please Enter your Name';
                }
                return null;
              },

              ),
             const  SizedBox(height: 26,),
              TextFormField(
              
                controller: emailcontroller,
                keyboardType: TextInputType.emailAddress,
                decoration:const  InputDecoration(hintText: 'Email',
                labelText:'Email',border: OutlineInputBorder(),),
                
                validator: (value){
                  if(value!.isEmpty){
                    return 'please enter email';
                  }
                  if (!isValidEmail(value!)){
                    return 'please enter Valid mail';
                    
                  }
                  return null;

                },
              ),
            const  SizedBox(height: 26,),
              TextFormField(
                controller:agecontroller, 
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(hintText:'Age',labelText: 'Age',border: OutlineInputBorder()),
                validator: (value){
                  if(value!.isEmpty){
                    return 'please enter a number';

                  }
                  if (int.tryParse(value)==null){
                    return 'please enter a valid value';

                  }
                },
              ),
              SizedBox(height: 26,),
              TextFormField(
                controller: passwordcontroller,
                keyboardType: TextInputType.number,
                obscureText: true,
                decoration: const InputDecoration(hintText: 'Password',labelText:'Password',border: OutlineInputBorder()),
                validator: (value){
                  if(value!.isEmpty){
                    return 'please enter password';

                  }
                  if (isValidPassword(value!)){
                    return 'please enter valid password';
                    
                  }
                },
              ),
         
           ],)
              ),),
            

            const SizedBox(height:26),
            IconButton(onPressed: (){
           if (_formkey.currentState!.validate()){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>DisplayScreen(
              name: textcontroller.text,
              age: int.parse(agecontroller.text),
              email: emailcontroller.text,
              password: passwordcontroller.text,
             // selectedDate: _selectedDate,
            )));

           }
            }, icon: Icon(Icons.person_add ,size: 40,color: Colors.blueGrey,)) ],
          ),
        )
       
      ],
        
     )),
      
     ) ));

    
  }

  bool isValidEmail(String email) { return RegExp(r'^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$').hasMatch(email);}

  bool isValidPassword(String pass) {return RegExp(
                        "^(?=.{8,32}\$)(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#\$%^&*(),.?:{}|<>]).*").hasMatch(pass);}
  
}